package com.cg.mobshop.dao;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.ui.IDException;

public interface MobileDAO {
	List<Mobiles>getMobileList();
	void deleteMobile(int mobcode) throws IDException;
	public List<Mobiles>SortList(int criteria);
}
