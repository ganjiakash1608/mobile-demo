package com.cg.mobshop.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;
import java.util.stream.Collectors;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.ui.IDException;
import com.cg.mobshop.util.CompareName;
import com.cg.mobshop.util.SortPrice;
import com.cg.mobshop.util.SortQuant;
import com.cg.mobshop.util.Util;

public class MobileDAOImpl implements MobileDAO {
	// Map to store the values from utilities.
	Map<Integer, Mobiles> map = new HashMap<Integer, Mobiles>(
			Util.getMobileEntries());
	// Created a list to store the values of the Map.
	// private static List<Mobiles> mobileList =
	// map.values().stream().collect(Collectors.toList());
	ArrayList<Mobiles> set = new ArrayList<>(map.values());
//
//	CompareName compareN = new CompareName();
//	SortPrice comparePrice = new SortPrice();
//	SortQuant compareQuant = new SortQuant();

	@Override
	public List<Mobiles> getMobileList() {
		List<Mobiles> mobile = new ArrayList<>();
		for (Mobiles mobiles : set) {
			mobile.add(mobiles);
		}
		return mobile;

	}

	@Override
	public void deleteMobile(int mobcode)throws IDException {
		set.remove(new Mobiles(mobcode, null, 0, 0));
		if (Util.getMobileEntries().containsKey(mobcode)) {
			System.out.println("hello");
		}
		else{
		throw new IDException("ID not found");}
	}

	@Override
	public List<Mobiles> SortList(int criteria) {
		if (criteria == 1)
			// Collections.sort(set, compareN);
			Collections.sort(set,
					(obj1, obj2) -> obj1.getName().compareTo(obj2.getName()));
		//set=set.stream().sort((obj1, obj2) -> obj1.getName().compareTo(obj2.getName())).collect(Collectors.toList());
		else if (criteria == 2)
			// Collections.sort(set, comparePrice);
			Collections
					.sort(set, (obj1, obj2) -> (int) (obj1.getPrice() - (obj2
							.getPrice())));
		else if (criteria == 3)
			// Collections.sort(set, compareQuant);
			Collections
					.sort(set, (obj1, obj2) -> (obj1.getQuantity() - (obj2
							.getQuantity())));
		return set;
	}

}
