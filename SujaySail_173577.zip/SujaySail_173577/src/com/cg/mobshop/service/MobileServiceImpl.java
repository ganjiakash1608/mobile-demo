package com.cg.mobshop.service;

import java.util.List;

import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.ui.IDException;

public class MobileServiceImpl implements MobileService {
	MobileDAOImpl dao = new MobileDAOImpl();
	@Override
	public List<Mobiles> getMobileList() {
		
		return dao.getMobileList();
	}

	@Override
	public void deleteMobile(int mobcode) throws IDException {
		dao.deleteMobile(mobcode);
		
	}

	@Override
	public List<Mobiles> SortList(int criteria) {
		return dao.SortList(criteria);
		
	}

}
