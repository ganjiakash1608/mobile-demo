package com.cg.mobshop.service;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.ui.IDException;

public interface MobileService {
	List<Mobiles>getMobileList();
	void deleteMobile(int mobcode) throws IDException;
	public List<Mobiles>SortList(int criteria);
}
