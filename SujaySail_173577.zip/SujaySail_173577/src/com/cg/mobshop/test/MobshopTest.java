package com.cg.mobshop.test;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobshop.dao.MobileDAO;
import com.cg.mobshop.dao.MobileDAOImpl;


public class MobshopTest {
MobileDAO dao = null;
	
	@Before
	public void setUp() throws Exception {
		
		dao = new MobileDAOImpl();
	}
	
	@After
	public void tearDown() throws Exception{
		dao = null;
	}
	
	@Test
	public void testValidateEntry(){
	Assert.assertNotNull(dao.getMobileList());
	}
	
}
