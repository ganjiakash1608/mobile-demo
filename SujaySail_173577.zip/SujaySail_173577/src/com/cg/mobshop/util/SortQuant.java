package com.cg.mobshop.util;

import java.util.Comparator;

import com.cg.mobshop.dto.Mobiles;

public class SortQuant implements Comparator<Mobiles> {

	@Override
	public int compare(Mobiles m1, Mobiles m2) {
		// TODO Auto-generated method stub
		return m1.getQuantity()-m2.getQuantity();
	}

}
