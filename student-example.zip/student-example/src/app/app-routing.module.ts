import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes, RouterModule} from '@angular/router';
import { StudentRegistrationComponent } from './student-registration/student-registration.component';
import { ListOfStudentsComponent } from './list-of-students/list-of-students.component';
import { SearchStudentComponent } from './search-student/search-student.component';

const routes: Routes = [
  { path: '', redirectTo: '/student-register', pathMatch: 'full' },
  { path: 'student-register', component: StudentRegistrationComponent, pathMatch: 'full'},
  { path: 'list-of-students', component: ListOfStudentsComponent, pathMatch: 'full'},
  { path: 'search-student', component: SearchStudentComponent, pathMatch: 'full'},
  { path: '**', redirectTo: '/student-register', pathMatch: 'full' }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
