import { Component, OnInit } from '@angular/core';
import { StudentService } from '../service/student.service';
import { StudentModel } from '../model/student-model';

@Component({
  selector: 'app-list-of-students',
  templateUrl: './list-of-students.component.html',
  styleUrls: ['./list-of-students.component.css']
})

export class ListOfStudentsComponent implements OnInit {

  studentArr: StudentModel[]
  studentToEdit:StudentModel;
  isEditing:boolean;

  constructor(private studentService:StudentService) { 
    this.studentArr = [];
    this.studentToEdit = new StudentModel()
  }

  ngOnInit() {
    this.studentArr = this.studentService.display();
  }

  sortstudentByName()
  {
    this.studentService.sortStudentByName();
  }

  sortStudentByRollno()
  {
    this.studentService.sortStudentByRollno();
  }

  delete(index: number) {
   this.studentService.delete(index);
  }

  edit(id:number)
  {
    this.isEditing = true;
    this.studentToEdit = this.studentService.edit(id);
  }

}