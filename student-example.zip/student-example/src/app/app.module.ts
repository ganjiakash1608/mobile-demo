import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ListOfStudentsComponent } from './list-of-students/list-of-students.component';
import { StudentRegistrationComponent } from './student-registration/student-registration.component';
import { SearchStudentComponent } from './search-student/search-student.component';
import { AppRoutingModule } from './app-routing.module';
import {FormsModule} from '@angular/forms'
import { StudentService } from './service/student.service';

@NgModule({
  declarations: [
    AppComponent,
    ListOfStudentsComponent,
    StudentRegistrationComponent,
    SearchStudentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [StudentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
