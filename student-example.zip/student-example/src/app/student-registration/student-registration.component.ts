import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { StudentService } from '../service/student.service';
import { StudentModel } from '../model/student-model';

@Component({
  selector: 'app-student-registration',
  templateUrl: './student-registration.component.html',
  styleUrls: ['./student-registration.component.css']
})
export class StudentRegistrationComponent implements OnInit {

   //to create new employee or edit it
   @Input()  student: StudentModel;

   // to control update button in form
   @Input() isEditing: boolean;
 
   @Output() edited = new EventEmitter();


 
  constructor(private studentService: StudentService) {
    this.student = new StudentModel();
  }
  insertStudent() {
    this.studentService.add(this.student);

  }

  update()
  {
    this.isEditing = false;
    this.student = new StudentModel();
    this.edited.emit();
  }
  ngOnInit() {
  }

}
