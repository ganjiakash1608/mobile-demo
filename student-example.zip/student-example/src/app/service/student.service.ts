import { Injectable } from '@angular/core';
import { StudentModel } from '../model/student-model';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  //create an array
 studentArr : StudentModel[]
//initialize it in constructor
  static counter:number=1001;
  constructor(private routes:Router) { 
    this.studentArr= []
  }
  add(student:StudentModel){
    student.rollno=StudentService.counter++;
    this.studentArr.push(student);
    this.routes.navigate(['/list-of-students']);
  }

  display(){
    return this.studentArr;
  }

  delete(index: number) {
    this.studentArr.splice(index, 1);
  }
  searchEmp(id: number) {
    var result = this.studentArr.find(x => x.rollno == id);
    if (result == null)
      return null; //if not found
    else
      return result; //if found then store it
  }


  sortStudentByName()
  {
    this.studentArr.sort((a,b)=>a.fname.localeCompare(b.fname.valueOf()));
    return this.studentArr;
  }

  sortStudentByRollno() {
    this.studentArr.sort((a, b) => a.rollno - b.rollno);
    return this.studentArr;
  }

  edit(id: number) {
    return this.studentArr.find(x => x.rollno == id);
  }
}
  
